ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1216023.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "default"
};
SCRIPTS = [ 53880251, 53880252, 53880253, 53881711, 53881724, 53881738, 53883273, 53940095, 53942913, 53950090, 53950219, 53951540, 53958870, 53958871, 53958914, 53968434, 53975347, 54162281, 54162334, 54167483 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
